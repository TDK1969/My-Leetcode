from setuptools import setup, find_packages
setup(
    name="leetcode_utils",
    version="1.0.2",
    description="tools function for leetcode",
    packages=find_packages()
)