# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.


# This test's id is double_nested_folder/nested_folder_one/nested_folder_two/test_nest.py::test_function.
# This test passes.
def test_function():  # test_marker--test_function
    assert 1 == 1
