# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.


def test_a_function():  # test_marker--test_a_function
    assert True
