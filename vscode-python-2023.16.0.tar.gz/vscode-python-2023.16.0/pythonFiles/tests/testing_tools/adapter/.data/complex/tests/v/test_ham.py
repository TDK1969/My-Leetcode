from .spam import test_simple
from .spam import test_simple as test_not_hard
