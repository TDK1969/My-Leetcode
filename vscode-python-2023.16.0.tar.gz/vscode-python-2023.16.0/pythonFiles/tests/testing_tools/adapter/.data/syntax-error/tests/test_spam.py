
def test_simple():
    assert True


# A syntax error:
:
